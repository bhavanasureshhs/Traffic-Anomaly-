
Traffic Numerical Anomaly Detection - Demo (Synthetic Dataset)
=============================================================

This project demonstrates an end-to-end anomaly detection pipeline using numerical traffic sensor data.

Project structure:
- data/traffic_numerical_dataset.csv : synthetic dataset with labels (0 normal, 1 anomaly)
- data/predictions_sample.csv : dataset with model scores and predicted labels
- models/isoforest_joblib.pkl : trained IsolationForest model
- scripts/train.py : script to retrain the model
- app/ : Flask web app to predict from form or JSON
- requirements.txt

How to run:
1. (Optional) Create a virtualenv and install:
   pip install -r requirements.txt

2. To retrain:
   python scripts/train.py

3. To run the Flask app:
   cd app
   python app.py
   Open http://localhost:5000

API:
POST /api/predict
Content-Type: application/json
Body: JSON with fields: ['vehicle_count', 'avg_speed', 'lane_density', 'time_of_day', 'heavy_vehicle_ratio', 'avg_headway']
Response: {'anomaly_score': float, 'is_anomaly': bool}

Notes:
- The model is an IsolationForest trained on normal data only. Thresholding for 'is_anomaly' in the demo is a heuristic.
- For production tune thresholds, add features, and validate with real labeled data.
