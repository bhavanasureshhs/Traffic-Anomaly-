
"""
train.py

Train an IsolationForest model on 'data/traffic_numerical_dataset.csv'.
Produces models/isoforest_joblib.pkl.
"""
import os
import joblib
import pandas as pd
from sklearn.ensemble import IsolationForest

root = os.path.dirname(os.path.dirname(__file__))
csv_path = os.path.join(root, "data", "traffic_numerical_dataset.csv")
df = pd.read_csv(csv_path)
columns = ["vehicle_count","avg_speed","lane_density","time_of_day","heavy_vehicle_ratio","avg_headway"]

# Train on normal instances only (if anomaly label available)
if "anomaly" in df.columns:
    X_train = df[df["anomaly"]==0][columns].values
else:
    X_train = df[columns].values

iso = IsolationForest(n_estimators=200, contamination=0.13, random_state=42)
iso.fit(X_train)
model_path = os.path.join(root, "models", "isoforest_joblib.pkl")
joblib.dump(iso, model_path)
print("Saved model to", model_path)
