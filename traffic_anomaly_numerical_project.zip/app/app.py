
from flask import Flask, request, render_template, jsonify
import os, joblib
import numpy as np
import pandas as pd

app = Flask(__name__)
MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "isoforest_joblib.pkl")
if not os.path.exists(MODEL_PATH):
    MODEL_PATH = os.path.join(app.root_path, "models", "isoforest_joblib.pkl")
model = joblib.load(MODEL_PATH)
FEATURES = ["vehicle_count","avg_speed","lane_density","time_of_day","heavy_vehicle_ratio","avg_headway"]

def predict_from_dict(d):
    arr = np.array([float(d[f]) for f in FEATURES]).reshape(1,-1)
    score = -model.decision_function(arr)[0]  # higher -> more anomalous
    # threshold: use model's contamination as approximate cutoff by scoring training distribution; 
    # here we'll classify as anomaly if score exceeds a reasonable heuristic (user can retrain and tune)
    is_anom = bool(score > 0.5)  # heuristic; you can retrain/model-specific threshold
    return {"anomaly_score": float(score), "is_anomaly": is_anom}

@app.route("/", methods=["GET","POST"])
def index():
    result = None
    error = None
    if request.method == "POST":
        try:
            # prefer JSON body
            if request.is_json:
                d = request.get_json()
            else:
                d = {k: request.form.get(k) for k in FEATURES}
            # ensure all features present
            for f in FEATURES:
                if d.get(f) is None:
                    raise ValueError(f"Missing feature: {f}")
            result = predict_from_dict(d)
        except Exception as e:
            error = str(e)
    return render_template("index.html", result=result, error=error, features=FEATURES)

@app.route("/api/predict", methods=["POST"])
def api_predict():
    if not request.is_json:
        return jsonify({"error":"Please send JSON body"}), 400
    d = request.get_json()
    try:
        for f in FEATURES:
            if f not in d:
                return jsonify({"error": f"Missing feature: {f}"}), 400
        res = predict_from_dict(d)
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
